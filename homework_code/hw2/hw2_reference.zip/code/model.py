import torch 
import torch.nn as nn
class Classifier(nn.Module):
    def __init__(self):
        super(Classifier, self).__init__()
        self.bn0 = nn.BatchNorm1d(429)
        self.layer1 = nn.Linear(429, 4096)  #429是样本特征个数， 1024第一层神经元个数
        self.bn1 = nn.BatchNorm1d(4096)
        self.layer2 = nn.Linear(4096,2048)
        self.bn2 = nn.BatchNorm1d(2048)
        self.layer3 = nn.Linear(2048, 1024)  #第二层神经元个数512
        self.bn3 = nn.BatchNorm1d(1024)
        self.layer4 = nn.Linear(1024, 512)   #第三层128
        self.bn4 = nn.BatchNorm1d(512)
        self.layer5 = nn.Linear(512, 128)
        self.bn5 = nn.BatchNorm1d(128)
        self.out = nn.Linear(128, 39)  #最后一层 39
        self.dropout = nn.Dropout(p = 0.5)
        self.dropout1 = nn.Dropout(p = 0.1)
        self.dropout3 = nn.Dropout(p = 0.3)
        self.sigmoid = nn.Sigmoid()
        self.relu = nn.LeakyReLU()  #激活函数

    def forward(self, x):

         #第一层前向传递
        x = self.bn0(x)
        x = self.layer1(x)
        x = self.bn1(x)
        x = self.sigmoid(x)
        x = self.dropout(x)
        #第二层前向传递
        x = self.layer2(x)
        x = self.bn2(x)
        x = self.sigmoid(x)
        #x = self.dropout(x)
        #第三层前向传递
        x = self.layer3(x)
        x = self.bn3(x)
        x = self.sigmoid(x)
        #x = self.dropout(x)
        #layer4
        x = self.layer4(x)
        x = self.bn4(x)
        x = self.sigmoid(x)
        x = self.dropout(x)
        
        #layer5
        x = self.layer5(x)
        x = self.bn5(x)
        x = self.sigmoid(x)
        #x = self.dropout(x)
        #最后一层输出
        x = self.out(x)
        return x