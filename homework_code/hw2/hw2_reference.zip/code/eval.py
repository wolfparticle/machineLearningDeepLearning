import torch
from torch.utils.data import DataLoader
import numpy as np
from model import Classifier
import get_device as gd
import TIMITDataset as td
"""
这个脚本主要用来中途评估模型

"""

device = gd.device()
model_path = 'model/model_04_01_15_47.ckpt'
data_root = '/opt/asr/notebook/hw2/ml2021spring-hw2/timit_11/'
test = np.load(data_root + 'test_11.npy')
test_set = td.TIMITDataset(test)
BATCH_SIZE = 256
test_loader = DataLoader(test_set, BATCH_SIZE, shuffle = False, num_workers = 64)


model =  Classifier().to(device)
ckpt = torch.load(model_path)  # Load your best model
model.load_state_dict(ckpt) #加载训练时保存的模型


#step 8 测试
predict = []
model.eval() #设置模型为评估模式
with torch.no_grad():
    for i, data in enumerate(test_loader):
        inputs = data
        inputs = inputs.to(device)
        outputs = model(inputs)
        _, test_pred = torch.max(outputs, axis = 1)
        for y in test_pred.cpu().numpy(): #y依然是一个array([])结构
            predict.append(y)

#step 9 保存预测结果
with open('predict/predict_04_01_20_21_03.csv', 'w') as f:
    f.write('Id,Class\n')
    for i, y in enumerate(predict):
        f.write('{},{}\n'.format(i, y))