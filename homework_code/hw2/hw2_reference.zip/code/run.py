import numpy as np
from torch.utils.data import DataLoader
import torch.nn as nn
import torch
import logging
import os
import time
from sklearn.model_selection import train_test_split

import get_device as gd 
import TIMITDataset as TD
from model import Classifier

#打印训练参数和模型到日志，方便分析， 这里进行日志配置设置
log_dir = 'log'  #保存训练日志
if not os.path.exists(log_dir):
    os.mkdir(log_dir)
model_dir = 'model'  #保存训练模型
if not os.path.exists(model_dir):
    os.mkdir(model_dir)
predict_dir = 'predict'   #保存预测结果
if not os.path.exists(predict_dir):
    os.mkdir(predict_dir)

t = time.strftime("%m_%d_%H_%M_%S", time.localtime())
log_file = '{}.log'.format(t)
log_path = os.path.join(log_dir, log_file)
logger = logging.getLogger()    
logger.setLevel(logging.DEBUG)  #设置日志级别为debug, 这样日志会比较多
logging.basicConfig(filename= log_path, format='[%(asctime)s-%(filename)s-%(levelname)s:%(message)s]',\
     level = logging.DEBUG, filemode='a',datefmt='%Y-%m-%d %I:%M:%S %p')        #日志格式配置

#step 0 设置训练环境, cpu训练还是gpu训练
logger.info("\n开始运行")
gd.same_seeds(0)    # fix random seed for reproducibility
device = gd.device()
train_only = False  #true开启只训练不评估和测试，这样节约训练时间，用于前期batch_size, lr, bn等参数选择
print(f'DEVICE: {device}')
logger.info("train_only:{}".format(train_only))

#step 1 导入数据
logger.debug("step 1 start")
print('Loading data ...')
logger.debug('Loading data ...')

data_root='/opt/asr/notebook/hw2/ml2021spring-hw2/timit_11/'
train = np.load(data_root + 'train_11.npy')
train_label = np.load(data_root + 'train_label_11.npy')
test = np.load(data_root + 'test_11.npy')

logger.debug('train shape: {}, train_label shape: {}, test shape: {}'.format(train.shape, train_label.shape, test.shape))
logger.debug('step 1 end')
#step 2 划分训练数据，划分为模型训练数据和验证数据
logger.debug('step 2 start')

VAL_RATIO = 0.3 #训练与验证之间比例， 8：2
percent = int(train.shape[0] * (1 - VAL_RATIO)) #训练样本个数
#train_x, train_y, val_x, val_y = train[:percent], train_label[:percent], train[percent:], train_label[percent:]
train_indice, val_indice = train_test_split([i for i in range(train.shape[0])], test_size=VAL_RATIO)
train_x, train_y, val_x, val_y = train[train_indice], train_label[train_indice], train[val_indice], train_label[val_indice]
print('size of train set:{}'.format(train_x.shape))
print('size of validation set:{}'.format(val_x.shape))

logger.info("VAL_RATIO is {}".format(VAL_RATIO))
logger.debug('size of train set:{}'.format(train_x.shape))
logger.debug('size of validation set:{}'.format(val_x.shape))
logger.debug('size of test set:{}'.format(test.shape))
if len(train_indice):
    logger.debug("使用随机划分")
logger.debug('step 2 end')
#setp 3 封装训练数据，转出模型需要格式,train_loader, val_loader
logger.debug("step 3 satart")
BATCH_SIZE = 256 #模型参数更新一次的数据集大小 默认64
num_workers = 32
train_set = TD.TIMITDataset(train_x, train_y)  #train_x, train_y封装成元组
val_set = TD.TIMITDataset(val_x, val_y)  #验证数据集
test_set = TD.TIMITDataset(test) #测试数据集，测试数据集是没有标签的
train_loader = DataLoader(train_set, BATCH_SIZE, shuffle = True, num_workers = num_workers) #train_loader 每一个数据大小 15375 * Batch_SIZE * features
val_loader = DataLoader(val_set, BATCH_SIZE, shuffle = False, num_workers = num_workers)   #验证数据和测试数据不用打乱
test_loader = DataLoader(test_set, BATCH_SIZE, shuffle = False)
logger.info("size of batch is {}".format(BATCH_SIZE))
logger.info("num of workers is {}".format(num_workers))
logger.debug("step 3 end")

#step 4  训练参数设置
logger.debug('step 4 start')
num_epoch = 1000  #所有数据集训练1000次
learning_rate = 0.0005  #学习率
weight_decay = 0 #1e-6
model_file = 'model_{}.ckpt'.format(t)
model_path = os.path.join(model_dir, model_file)

logger.info("num of epoch is {}".format(num_epoch))
logger.info("learning_rate is {}".format(learning_rate))
logger.info("weight_decay is {}".format(weight_decay))
logger.debug("model_file {}".format(model_file))
logger.debug('step 4 end')
#step 5 创建模型训练，定义损失函数，定义优化方法
logger.debug('step 5 start')
model = Classifier().to(device)
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr = learning_rate, weight_decay = weight_decay)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.1, patience=5, verbose=True)
logger.debug('step 5 end')
#step 6 开始训练
logger.debug('step 6')
best_acc = 0.0 #保存每个epoch最好的结果
max_train_acc = 0
early_stop_cnt = 0
early_stop = 5
logger.info("early_stop is {}".format(early_stop))
val_acc_first = 0.74
for epoch in range(num_epoch):
    train_acc = 0.0
    train_loss = 0.0
    val_acc = 0.0
    val_loss = 0.0

    #training 
    model.train() #设置model为train模式
    if epoch == 0:
        logger.info("network frame \n, {}".format(model))
    for batch_idx, data in enumerate(train_loader):   #i表示一个batch的训练
        inputs, labels = data #一个batch的输入数据和标签
        inputs, labels = inputs.to(device), labels.to(device)  #加载gpu里
        optimizer.zero_grad() #梯度清零
        outputs = model(inputs) # shape 64 * 429
        batch_loss = criterion(outputs, labels) 
        _, train_pred = torch.max(outputs, axis = 1) # max返回模型预测每个样本label, 这里label就是0-38的编号
        batch_loss.backward() #求梯度
        optimizer.step() #更新参数
        train_acc += (train_pred.cpu() == labels.cpu()).sum().item()   #一个batch样本训练正确样本统计
        train_loss += batch_loss.item()  #一个batch样本训练loss计算
    mean_loss = train_loss / (batch_idx + 1)  # 一个epoch上平均损失
    #scheduler.step(mean_loss)  #学习率调整
    #一个epoch训练结束，评估一次
    if len(val_set) > 0 and not train_only :
        model.eval() #设置模型为评估模式
        with torch.no_grad():
            for i, data in enumerate(val_loader):
                inputs, labels = data
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                batch_loss = criterion(outputs, labels)
                val_max, val_pred = torch.max(outputs, axis = 1)
                val_acc += (val_pred.cpu() == labels.cpu()).sum().item()
                val_loss += batch_loss.item()
        
            print('[{:03d}/{:03d}] Train acc: {:3.6f} Train loss: {:3.6f} | Val acc: {:3.6f} Val loss: {:3.6f}'.format(epoch, num_epoch
                # train acc 算的是所有训练样本平均
                , train_acc / len(train_set)
                # train_loss 算的是每个批次train loss的平均
                , train_loss / len(train_loader)
                , val_acc / len(val_set)
                , val_loss / len(val_loader)))
            
            logger.info('[{:03d}/{:03d}] Train acc: {:3.6f} Train loss: {:3.6f} | Val acc: {:3.6f} Val loss: {:3.6f}'.format(epoch, num_epoch
                # train acc 算的是所有训练样本平均
                , train_acc / len(train_set)
                # train_loss 算的是每个批次train loss的平均
                , train_loss / len(train_loader)
                , val_acc / len(val_set)
                , val_loss / len(val_loader)))
        
            if (val_acc - val_acc_first) > 0.02:
                val_acc_first = val_acc
                predict = []
                for batch_idx, data in enumerate(test_loader):
                    inputs = data
                    inputs = inputs.to(device)
                    outputs = model(inputs)
                    _, test_pred = torch.max(outputs, axis = 1)
                    for y in test_pred.cpu().numpy(): #y依然是一个array([])结构
                        predict.append(y)
                pre_file = 'train_{}_val_{}.csv'.format(train_acc / len(train_set), val_acc / len(val_set))
                pre_path = os.path.join(predict_dir, pre_file)
                with open(pre_path, 'w') as f:
                    f.write('Id,Class\n')
                    for i, y in enumerate(predict):
                        f.write('{},{}\n'.format(i, y))

            #如果模型有改进，保存当前训练的模型
            if val_acc > best_acc:
                best_acc = val_acc
                if not train_only:
                    torch.save(model.state_dict(), model_path)
                    print('saving model with acc {:.3f}'.format(best_acc / len(val_set)))
                
                    logger.debug('saving model with acc {:.3f}'.format(best_acc / len(val_set)))
    else:
        print('[{:03d}/{:03d}] Train Acc: {:3.6f} Loss: {:3.6f}'.format(epoch + 1, num_epoch
            , train_acc / len(train_set)
            , train_loss / len(train_loader)
        ))
        if epoch == 1:
            logger.info("使用全量数据")
        logger.info('[{:03d}/{:03d}] Train Acc: {:3.6f} Loss: {:3.6f}'.format(epoch, num_epoch
            , train_acc / len(train_set)
            , train_loss / len(train_loader)
        ))

    if train_acc > max_train_acc:
        max_train_acc = train_acc
        early_stop_cnt = 0
    else:
        early_stop_cnt += 1
    if early_stop_cnt > early_stop:
        break

if len(val_set) == 0:    #如果不存在验证集，那么保留最有一个epoch的模型
    torch.save(model.state_dict(), model_path)
logger.debug('step 6 end')
logger.info('train end')

if not train_only:
    #step 7 使用模型
    logger.info('test start')
    logger.debug('step 7 start')
    del model  #原来模型还在内存，把它删了，重建一个模型
    model =  Classifier().to(device)
    ckpt = torch.load(model_path)  # Load your best model
    model.load_state_dict(ckpt) #加载训练时保存的模型
    logger.debug('step 7 end')
    #step 8 测试
    logger.debug('step 8 start')
    predict = []
    model.eval() #设置模型为评估模式
    with torch.no_grad():
        for batch_idx, data in enumerate(test_loader):
            inputs = data
            inputs = inputs.to(device)
            outputs = model(inputs)
            _, test_pred = torch.max(outputs, axis = 1)
            for y in test_pred.cpu().numpy(): #y依然是一个array([])结构
                predict.append(y)

    logger.debug('step 8 end')
    #step 9 保存预测结果
    logger.debug('step 9 start')
    pre_file = 'predict_{}.csv'.format(t)
    pre_path = os.path.join(predict_dir, pre_file)
    with open(pre_path, 'w') as f:
        f.write('Id,Class\n')
        for i, y in enumerate(predict):
            f.write('{},{}\n'.format(i, y))

    logger.debug('step 9 end')
    logger.info('test end')









