import torch
from torch.utils.data import Dataset
import numpy as np

class TIMITDataset(Dataset):
    def __init__(self, X, y = None):

        #讲数据转换成float型tensor
        self.data = torch.from_numpy(X).float()
        
        #如果是训练集，label也要转换为tensor, 如果是测试集，不需要转换
        if  y is not None:
            y = y.astype(np.int)   #y原来是字符串形式的numpy, baseline模型最后输出是sigmod函数，输出是个数值，所以这里转换成整数。
            self.label = torch.LongTensor(y)
        else:                      #如果是测试集，标签为None
            self.label = None

    #使TIMITDataset能索引，后续dataload能调用
    def __getitem__(self, idx):
        if self.label is not None:
            return self.data[idx], self.label[idx]  #返回训练数据
        else:
            return self.data[idx]  #返回测试数据

    def __len__(self):
        return len(self.data)  #改写这个方法为了能进行batch切分

